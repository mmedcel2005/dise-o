# ProyectoInterfaces
Proyecto hecho por Manuel Medina y Alejandro Ceballos

Estado actual:

-index funcionando y completo, pendiente de correcciones

-barra de navegación activa, los botones de la derecha abren las acciones posibles. La opción catálogo en el botón guitarra abre un offcanvas
de navegación por secciones en cualquier página de la aplicación web.

-formulario de registro presente. Pendiente de resolución de un fallo en la responsividad para móviles (Prioritario!). Scripts de control de formulario funcional, pero actualmente desactivado hasta no aclarar cuales serán los parámetros reales de condición de los campos del formulario.

-Próximos pasos:
    -Página de catálogo de secciones (Como muestra se hará catálogo de instrumentos de cuerda)(Prioritario!)
    -Página de producto (Se hará aprovechando la Navidad, hay bocetos, pero queremos replantearlo para dar más creatividad e individualidad)
    -Readaptación del formulario de venta de productos de segunda mano para usuarios (Pendiente de aprender un poco más de la tecnología AJAX)
    -Ventana de usuario (Cambio de avatar info del usuario, lista de favoritos, lista de últimas compras, lista de envíos pendientes, lista de direcciones registradas, etc)
    -Resto de páginas de la aplicación web.
